Вся информация находится на Github.
https://github.com/Camyil-89/WordOFF-Publish

Проблемы с запуском
Если не запускается приложение, необходимо скачать dotnet sdk 6.0

https://dotnet.microsoft.com/en-us/download/dotnet/6.0