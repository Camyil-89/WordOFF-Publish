Проблемы с запуском
Если не запускается приложение, необходимо скачать dotnet sdk 6.0

https://dotnet.microsoft.com/en-us/download/dotnet/6.0